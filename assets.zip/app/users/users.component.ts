import { Component, OnInit } from '@angular/core';
import { UsersService } from '../service/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private userService : UsersService) { }

  columns = ["id","name", "phone", "email","company","date_entry","org_num","address_1","city",
  "zip","geo","pan","status","pin","fee","guid","date_first","date_recent","url"];

  async ngOnInit() {

   let users =  await this.userService.getUsers();
   console.log(users);

  }

}
