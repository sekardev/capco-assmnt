import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  userdata: string [];

  constructor(private httpService : HttpClient) { }

  getUsers(){
    this.httpService.get('./assets/sample-data.json').subscribe(
      data => {
        this.userdata = data as string [];	 
         console.log(this.userdata[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
}
