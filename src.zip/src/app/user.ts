export class Users
{
    name:string;
    phone:string;
    email:string;
    company:string;
    date_entry:string;
    org_num:string;
    address_1:string;
    city:string;
    zip:string;
    geo:string;
    pan:string;
    pin:string;
    id:Number;
    status:string;
    fee:string;
    guid:string;
    date_exit:string;
    date_first:string;
    date_recent:string;
    url:string;
    constructor(id,name, phone, email,company,date_entry,org_num,address_1,city,zip,geo,pan,status,pin,fee,guid,
        date_first,date_recent,url)
    {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.company = company;
        this.date_entry = date_entry;


        this.org_num = org_num;
        this.address_1 = address_1;
        this.city = city;
        this.zip = zip;
        this.geo = geo;
        this.pan = pan;


        this.pin = pin;
        this.status = status;
        this.fee = fee;
        this.guid = guid;
        this.date_first = date_first;
        this.date_recent = date_recent;
        this.url = url;
        
        

    }
    
	
}